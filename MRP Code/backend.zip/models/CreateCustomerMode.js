const mongoose = require("mongoose");
const customerSchema = new mongoose.Schema(
  {
    company_name: {
      type: String,
      max: 50,
    },
    tax_vat: {
      type: String,
      max: 50,
    },
    customer_mobile: {
      type: String,
      unique: true,
      max: 50,
    },
    customer_email: {
      type: String,
      max: 50,
    },
    customer_name: {
      type: String,
      max: 50,
    },
    firm_status: {
      type: String,
      max: 50,
    },
    customer_type: {
      type: String,
      max: 50,
    },
    buiness_type: {
      type: String,
      max: 50,
    },
    pan_number: {
      type: String,
      max: 50,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("mrpcustomer", customerSchema);
