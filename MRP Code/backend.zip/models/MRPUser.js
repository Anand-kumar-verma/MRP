const mongoose = require("mongoose");

const mrpuserSchema = new mongoose.Schema({
  f_name: {
    type: String,
    required: true,
    max: 50,
  },
  l_name: {
    type: String,
    required: true,
    max: 50,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    max: 50,
  },
  password: {
    type: String,
    required: true,
    max: 50,
  },
  type: {
    type: String,
    required: true,
    max: 50,
  }
});

module.exports = mongoose.model("mrpuser", mrpuserSchema);
