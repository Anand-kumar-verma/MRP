const mongoose = require("mongoose");

const vendorSchema = new mongoose.Schema(
  {
    vendor_name: {
      type: String,
      max: 50,
    },
    vendor_mobile: {
      type: String,
      max: 50,
    },
    vendor_email: {
      type: String,
      unique: true,
      max: 50,
    },
    company_name: {
      type: String,
      max: 50,
    },
    firm_status: {
      type: String,
      max: 50,
    },
    vendor_type: {
      type: String,
      max: 50,
    },
    gst_category: {
      type: String,
      max: 50,
    },
    gst_number: {
      type: String,
      max: 50,
    },
    pan: {
      type: String,
      max: 50,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("mrpvendor", vendorSchema);
