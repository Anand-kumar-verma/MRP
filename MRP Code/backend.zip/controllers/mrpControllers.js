const bcrypt = require("bcrypt");
const MRPUser = require("../models/MRPUser");
const jwt = require("jsonwebtoken");
const CreateVendorMode = require("../models/CreateVendorMode");
const CreateCustomerMode = require("../models/CreateCustomerMode");
require("dotenv").config();

//signup route handler
exports.signMrpUser = async (req, res) => {
  try {
    //get data
    const { f_name, l_name, email, password, type } = req.body;
    console.log(f_name, l_name, email, password, type);
    //check if user already exist
    const existingUser = await MRPUser.findOne({ email });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: "User already Exists",
      });
    }

    const obj = new MRPUser({
      f_name,
      l_name,
      email,
      password,
      type,
    });

    const result = await obj.save();

    return res.status(200).json({
      success: true,
      msg: "User Created Successfully",
      data: result,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "User cannot be registered, please try again later",
    });
  }
};
exports.getAllMrpUser = async (req, res) => {
  try {
    //get data

    const result = await MRPUser.find({});

    return res.status(200).json({
      success: true,
      msg: "User Created Successfully",
      data: result,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "User cannot be registered, please try again later",
    });
  }
};

//login
exports.loginmrpuser = async (req, res) => {
  try {
    //data fetch
    const { email, password } = req.body;
    console.log(email, password);
    //validation on email and password
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "PLease fill all the details carefully",
      });
    }

    //check for registered user
    let user = await MRPUser.findOne({ email: email, password: password });
    //if not a registered user
    if (!user) {
      return res.status(401).json({
        success: false,
        message: "User is not registered",
      });
    }

    const payload = {
      email: user.email,
      id: user._id,
      type: user.type,
    };
    let token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: "2h",
    });

    user = user.toObject();
    user.token = token;
    user.password = undefined;

    const options = {
      expires: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      httpOnly: true,
    };

    return res.cookie("babbarCookie", token, options).status(200).json({
      success: true,
      token,
      user,
      message: "User Logged in successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: "Login Failure",
    });
  }
};
// create vendor
exports.createVendor = async (req, res) => {
  try {
    //data fetch
    const {
      vendor_name,
      vendor_mobile,
      vendor_email,
      company_name,
      firm_status,
      vendor_type,
      gst_category,
      gst_number,
      pan,
    } = req.body;
    console.log(vendor_name, vendor_mobile);
    //validation on email and password
    if (!vendor_email || !vendor_mobile) {
      return res.status(400).json({
        success: false,
        message: "PLease fill all the details carefully",
      });
    }

    //check for registered user
    let user = await CreateVendorMode.findOne({ vendor_email: vendor_email });
    //if not a registered user
    if (user) {
      return res.status(401).json({
        success: false,
        message: "Email already registered",
      });
    }

    const obj = new CreateVendorMode({
      vendor_name,
      vendor_mobile,
      vendor_email,
      company_name,
      firm_status,
      vendor_type,
      gst_category,
      gst_number,
      pan,
    });

    const response = await obj.save();
    return res.status(200).json({
      success: true,
      data: response,
      message: "User Logged in successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: "Login Failure",
    });
  }
};
exports.getVendorList = async (req, res) => {
  try {
    let user = await CreateVendorMode.find({});

    return res.status(200).json({
      success: true,
      data: user,
      message: "User Logged in successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: "Login Failure",
    });
  }
};
// create customer
exports.createCustomer = async (req, res) => {
  try {

    const {
      company_name,
      tax_vat,
      customer_mobile,
      customer_email,
      customer_name,
      firm_status,
      customer_type,
      buiness_type,
      pan_number,
    } = req.body;
    //validation on email and password
    if (!customer_email || !customer_mobile) {
      return res.status(400).json({
        success: false,
        message: "PLease fill all the details carefully",
      });
    }

    //check for registered user
    let user = await CreateCustomerMode.findOne({ customer_email: customer_email });
    //if not a registered user
    if (user) {
      return res.status(401).json({
        success: false,
        message: "Email already registered",
      });
    }

    const obj = new CreateCustomerMode({
      company_name,
      tax_vat,
      customer_mobile,
      customer_email,
      customer_name,
      firm_status,
      customer_type,
      buiness_type,
      pan_number,
    });

    const response = await obj.save();
    return res.status(200).json({
      success: true,
      data: response,
      message: "User Logged in successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: "Login Failure",
    });
  }
};
exports.getCustomerList = async (req, res) => {
  try {
    let user = await CreateCustomerMode.find({});

    return res.status(200).json({
      success: true,
      data: user,
      message: "User Logged in successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: "Login Failure",
    });
  }
};