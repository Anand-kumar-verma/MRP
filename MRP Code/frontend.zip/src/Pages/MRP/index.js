import React from 'react'

const MRP = () => {
  return (
    <div>MRP</div>
  )
}

export default MRP