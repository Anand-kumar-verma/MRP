import React from 'react'

const GeneralSetting = () => {
  return (
    <div>GeneralSetting</div>
  )
}

export default GeneralSetting