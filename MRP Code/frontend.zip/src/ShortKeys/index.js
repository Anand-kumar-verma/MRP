
export const keyMap = {
    SAVE: 'shift+s',
    SAVE_AND_NEW:'shift+n',
    ADD_NEW_ROW:'shift+r'
  };

  