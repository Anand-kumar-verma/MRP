import React from 'react'

const PaymentInformation = () => {
  return (
    <div>PaymentInformation</div>
  )
}

export default PaymentInformation