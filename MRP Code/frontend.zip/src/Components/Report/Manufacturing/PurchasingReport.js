import React from 'react'

const PurchasingReport = () => {
  return (
    <div>PurchasingReport</div>
  )
}

export default PurchasingReport