import React from "react";

const AllProjectsReport = () => {
  return <div>AllProjectsReport</div>;
};

export default AllProjectsReport;
