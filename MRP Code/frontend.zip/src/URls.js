// export const baseUrl = "http://192.168.1.90:9095/"

// export const  baseUrl = "http://192.168.1.90:9095/"

// export const baseUrl = "http://192.168.1.90:9898/";

export const baseUrl = "http://192.168.227.149:5000";

// export const baseUrl = "https://mrpb1.aaragroups.com/";
