export const firm = [
  ("None", "None"),
  ("Individual", "Individual"),
  ("Proprietor", "Proprietor"),
  ("Partner", "Partner"),
  ("Company", "Company"),
  ("Overseas", "Overseas"),
  ("Cooperative Society", "Cooperative Society"),
];

export const gst_cat = [
  ("None", "None"),
  ("Registered", "Registered"),
  ("Unregistered", "Unregistered"),
  ("Composition", "Composition"),
  ("UIN_SEZ", "UIN_SEZ"),
];
export const vendor_cat = [
  ("Online", "Online"),
  ("Offline", "Offline"),
  ("Retailer", "Retailer"),
];
